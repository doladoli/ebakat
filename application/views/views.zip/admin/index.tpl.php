<table class="ltable" id="mytable">
<tr class="header">
	<th>Bil.</th>
	<th>No Matrik</th>
	<th>Nama/No. KP</th>
	<th>Singkatan</th>
	<th>Program</th>
	<th>Gambar</th>
	<th>Status Cetak</th>
	<th>Papar Kad</th>
</tr>
<tbody>
<?=$this->load->view("admin/listpending.tpl.php", array("users"=>$users));?>
</tbody>
</table>
<input type="hidden" id="lastsync" value="<?=time()?>">
<script>
window.setInterval (
	function () {
		//alert('sdsd');
		php.beforeSend = function (){
			//	alert('test')
		}
		$.php('<?=base_url()?>index.php/photo/reload', {'lastsync' : $("#lastsync").val()});
	},
60000); //loop 1 stgh saat sekali
</script>