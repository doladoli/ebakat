
<?php $i=0; foreach ($users->result() as $u){ ?>
<tr class="list">
	<td><?php echo ++$i?></td>

	<td valign="middle"><?php echo $u->PEL_NO_MATRIK?></td>	
	<td><b><?php echo $u->PEL_NAMA_PELAJAR?></b></td>	

	<td><?php echo $u->PRG_NAMA_PROGRAM_BM?></td>	
	<td><?php echo $u->KETERANGAN_MASALAH?></td>	
	<td><img src="<?php echo base_url().$u->PEL_NO_MATRIK?>" width="80px">
	
	<td align="center"><a href="<?php echo base_url()?>index.php/admin/muatnaik/<?=$u->ID?>">Papar</a></td>	

</tr>
<?php }?>